# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

"""
Purpose

AWS Lambda function that handles calls from an Amazon API Gateway REST API.
"""

import json
import boto3
import uuid
import requests

def lambda_handler(event, context):
    
    client = boto3.client('kinesis')
    body = json.loads(event['body'])
    
    url = "https://api.shasta.trongrid.io/wallet/getnowblock"
    headers = {"accept": "application/json"}
    tron_text = requests.post(url, headers=headers).text
    block = json.loads(tron_text)['block_header']['raw_data']['number']
    
    body['block'] = block

    response = client.put_record(
        StreamName='canaal-input',
        Data=json.dumps(body),
        PartitionKey=str(uuid.uuid4()))

    return {
        'statusCode': 200,
    }
